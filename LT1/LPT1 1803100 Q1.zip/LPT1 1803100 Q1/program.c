#include <math.h>

int main()
{
    float a = 10.1;
    float b = 20.2;
    float c = a + b;
    return 0;
}